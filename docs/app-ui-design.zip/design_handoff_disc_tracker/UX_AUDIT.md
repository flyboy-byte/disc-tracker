# Disc Tracker — UI convention audit (Android app)

Audit of all five tab screens plus their sub-views and modals, done by reading the source:
`app/app/(tabs)/{index,flight-shaper,disc-suggest,score,settings}.tsx`, `app/app/(tabs)/_layout.tsx`,
and `app/src/components/*`.

**What this is:** each finding is measured against a *stated convention* — Android/Material
guidance, platform expectation, or an inconsistency with your own patterns elsewhere in the app —
not against personal taste. Where something is a judgment call, it says so.

**What this is not:** a performance, correctness or architecture review. Several findings need
on-device confirmation (noted inline); the code alone can't tell you how a gesture feels.

Severity: **P0** correctness / accessibility · **P1** convention violation or internal
inconsistency · **P2** polish.

---

## A. Cross-cutting (fix once, every screen benefits)

### A1 · P1 — Five different treatments for "pick one of N"

The same interaction has five visual vocabularies:

| Component | File | Radius | Selected fill |
|---|---|---|---|
| `segment` / `segmentBtn` (Today's Bag / Collection) | index.tsx | 10 outer, 8 inner | `rgba(145,94,255,0.16)` |
| `pill` (stability, type, sort filters) | index.tsx | 12 | `rgba(145,94,255,0.28)` |
| `arcViewPill` (RHBH/RHFH/LHBH/LHFH) | index.tsx, flight-shaper.tsx | 6 | `rgba(145,94,255,0.12)` |
| `modeHalf` (Throw / Buy) | disc-suggest.tsx | 50/50 thick bar | filled |
| `holePresetPill` (9 / 18 / Custom), settings `pill` | score.tsx, settings.tsx | own values | own values |

Three selected-state alphas (0.12 / 0.16 / 0.28) for one meaning. A user learns "purple tint =
selected" and then meets three strengths of it.

**Fix:** two components, two roles.
- `<SegmentedControl>` — mutually exclusive, always shows all options (arc view, Throw/Buy,
  Today's/Collection, skill level, throw style, hole preset).
- `<FilterPill>` — additive/optional narrowing (stability, type, brand, category).

Add two tokens to `theme.ts` and use only these: `accentTint: 'rgba(145,94,255,0.16)'`,
`accentTintStrong: 'rgba(145,94,255,0.28)'`.

### A2 · P0 — Touch targets below Android's 48dp minimum

Material's minimum is 48×48dp; 44 is the absolute floor. Measured from your styles
(padding + font line box):

| Control | File | Approx. height | Has `hitSlop`? |
|---|---|---|---|
| `arcViewPill` (paddingVertical 3, fontSize 10) | index.tsx:~/flight-shaper.tsx | ~22dp | no |
| `pill` (paddingVertical 6, fontSize 12) | index.tsx, settings.tsx | ~28dp | no |
| `ghostBtn` (paddingVertical 8, fontSize 13) | index.tsx, score.tsx | ~33dp | no |
| `reorderBtn` (34×30) ×3 adjacent | DiscCard.tsx | 30dp | `hitSlop={6}` → 42dp |
| `selBarBtn` (padding 4) | index.tsx | ~26dp | no |
| `filterChevron` / `chevron` glyph rows | index.tsx, flight-shaper.tsx | text-sized | no |
| `bagCheck` pill (paddingVertical 4) | DiscCard.tsx | ~26dp | `hitSlop={8}` → 42dp |

**Fix:** keep every visual size exactly as-is; add `hitSlop` or `minHeight: 44` +
`justifyContent: 'center'`. This is invisible in a screenshot and very visible in the hand — it is
the single highest-value change in this document.

Three adjacent 30dp reorder buttons (`⤒ ↑ ↓`) are the worst case: small, side by side, and one of
them is destructive to list order. Consider one full-height drag handle in an explicit reorder
mode instead.

### A3 · P1 — Text glyphs used as icons

`▾ ▴ ▸ › ‹ ✕ ⤒ ↑ ↓ ✓ Σ –` appear as interface icons across all five screens. Three problems:
OEM font stacks render them at different weights and baselines (they will not sit centered on
every device); they don't scale or tint with your real icon set; and TalkBack reads them literally
("black down-pointing small triangle").

You already have the right answer in the codebase — `TabBarIcon.tsx` draws clean 24px
`react-native-svg` line icons with no new dependency. Extend it into a small `Icon` component
(`chevron-down`, `chevron-right`, `close`, `check`, `arrow-up`, `arrow-to-top`, `sigma`→"Tot").

Same root cause as the emoji in `scenarios.ts` — one icon language, drawn, not typed.

### A4 · P0 — Dynamic type / font scaling

Every `fontSize` is a fixed number, and the chrome leans on 10–12px labels (`legendText` 11,
`arcViewPillText` 10, `filterGroupLabel` 10, `sliderUnit`, `fieldScopeNote` 11). Android users can
set font scale to 130–200%; RN scales text by default with no clamp, so those rows will wrap or
clip and the dense pill rows will overlap.

**Fix:** set `maxFontSizeMultiplier` (≈1.4) on dense chrome labels only — never on body copy or
score numbers — and raise anything below 12sp that carries real information. Verify on-device at
200% (Settings → Display → Font size, largest).

### A5 · P1 — Color as the only signal in the scorecard grid

Stability badges do this right: `OS`/`ST`/`US` carry a letter as well as a hue. But
`TIER_COLOR[scoreTier(...)]` in score.tsx colors stroke numbers by birdie/par/bogey with **no**
second channel. Roughly 8% of men have red-green color deficiency, and disc golf skews heavily
male.

**Fix:** add a shape or weight channel — circle outline for under par, plain for par, filled/box
for over par — as real scorecards do.

### A6 · P2 — Tab labels

`_layout.tsx` sets `title: 'Flight Shaper'` and `'Disc Suggest'`. Five tabs with two-word labels
truncate on narrow devices and at raised font scale; Material asks for one word where possible.
Suggest `Shaper` and `Suggest` (the screens keep their full titles).

---

## B. Bag (`index.tsx`)

### B1 · P1 — The action row can reach seven equal-weight buttons

`actionsRow` renders, conditionally: **Add disc · Import · Export · Share · My library (n) ·
Clear bag · Field view**, all `ghostBtn` except the gradient primary, wrapping onto two or three
lines above the list.

Android's convention for a long tail of screen-level actions is a top-app-bar overflow (⋮), not a
wrapping button field. Recommended split:

- **Primary, always visible:** `+ Add disc` (gradient).
- **Inline toggle:** `Field view` — it's a view-mode switch, and belongs next to the filter row,
  not in the actions.
- **Overflow ⋮:** Import, Export, Share, My library, Clear bag.

This also fixes B2 below.

### B2 · P1 — Destructive action styled as a neutral one

`Clear bag` is a `ghostBtn` identical to `Export`. `colors.danger` (#f87171) exists in the theme
and is used in score.tsx (`selBarDelete`) and settings (`danger`) — but not here. It does have an
`Alert` confirm (index.tsx:451), which is the important half; the visual half is missing.

**Fix:** in the overflow menu, render it last, separated, in `colors.danger`.

### B3 · P1 — Pager is a web pattern

The `ListFooterComponent` renders `‹ Prev · Page 1 of 4 · Next ›`. Android expects continuous
scroll; `FlatList` is already virtualizing (`initialNumToRender`, `windowSize`,
`removeClippedSubviews`), so the pager isn't buying performance the list doesn't already have.

**Fix:** `onEndReached` + `onEndReachedThreshold={0.5}` appending the next page, with a small
footer spinner. Keeps the mount-bound cliff fix from `b2-spike.md` and removes two controls.
(Judgment call: a pager is defensible if you *want* a hard cap on mounted cards — but then the
label should say "Showing 1–30 of 112", which is the information the user actually wants.)

### B4 · P1 — Undiscoverable interactions carried by hint text

Two instructional strings do work the UI should do: `dragHint` ("use ⤒ / ↑ / ↓ on a card to
reorder" / "clear search/filters to reorder") and multiselect-by-long-press with no visible
affordance at all.

Long-press-to-select is a legitimate Android convention (contextual action bar) — so the pattern is
right — but pair it with a visible entry point: a "Select" text button in the header when the list
is non-empty. Hint text is a fallback, not a mechanism.

### B5 · P2 — Search field misses two Android defaults

`styles.search` has no clear (✕) affordance and no `returnKeyType="search"` /
`clearButtonMode` equivalent. Add a trailing clear icon when non-empty, and
`returnKeyType="search"` so the IME shows the right action key.

### B6 — What's working (keep)

Empty states are genuinely well done: three distinct states (no discs / today's bag empty /
no filter matches) each with its own icon, copy and correct next action — most apps ship one. The
`activeFilterCount` badge on the filter toggle is exactly right. Per-card arc thumbnails are the
app's best idea and should never be cut for density.

---

## C. Flight Shaper (`flight-shaper.tsx`)

### C1 · P1 — Arc-view selector as a 2×2 grid

Four boxed buttons ~120dp tall above the arc — the screen's actual subject. Collapse to one
segmented row (see A1). Frees ~70dp for the arc. *(Already specified in the earlier handoff.)*

### C2 · P1 — Slider labeling is split across the control

Each `SliderCol` reads: label ("Hyzer") → value ("+12°") → track → unit ("degrees"). The unit is
80dp away from the value it qualifies, and there are no end labels, so the range is invisible —
a user cannot tell whether +12° is near the maximum without dragging to find out.

**Fix:** value and unit on one line ("+12°" with "deg" as a suffix at 60% opacity); put `min` and
`max` at the track ends at 11sp; add a tick or detent at the neutral value.

The neutral-value point matters most: Hyzer/Nose/Wind default to 0 and Arm/Spin to 100, and
`isDefault` already colors the value `muted` vs `accent` (good, keep) — but there's no way to
*snap back* to it except the global Reset. A double-tap-to-reset on a single slider is the
convention.

### C3 · P2 — Reset is always enabled

`resetBtn` is live even when every slider is already at default; tapping does nothing and gives no
feedback. Disable at 45% opacity when `sliders` deep-equals `DEFAULT_SLIDERS`.

### C4 · P1 — The physics-sim explainer is documentation inside a control panel

`simInfo` renders a five-line paragraph, and `caveat` adds another, both inline in the Conditions
card between the toggle and the sliders. Same species as the Settings backup explainer.

**Fix:** one line next to the toggle + an (i) icon button opening a dialog with the full text
verbatim. Nothing gets deleted; it stops sitting between the user and the sliders.

### C5 — Vertical sliders: keep, but know what you're trading

There is no Android platform precedent for vertical sliders, and `VerticalSlider.tsx`'s own
comments document the gesture fight this caused inside a `ScrollView`. Against that: the vertical
axis is a real metaphor for hyzer angle, and it lets five controls sit side by side.

**Verdict: keep them** — this is the app's signature and the metaphor is honest. Two mitigations
worth the effort: (a) widen `hitArea` beyond 44 if the layout allows, since a mis-grab currently
scrolls the page; (b) confirm on-device that `onSlidingStart` → `setScrollEnabled(false)` never
leaves scroll locked if a gesture is cancelled by a phone call or app switch — a stuck-locked
scroll view is unrecoverable without leaving the tab.

---

## D. Disc Suggest (`disc-suggest.tsx`)

### D1 · P1 — Emoji icons

`scenarios.ts` mixes full-color emoji (`🚀 🌬 💨 ✋ 🪓`) with monochrome glyphs (`➡ ↙ ↗ ⊙ ↪ ⟳ 〰`).
Vector line icons in the `TabBarIcon.tsx` style. *(Specified in the earlier handoff.)*

### D2 · P1 — Tabs inside tabs

The Throw / Buy `modeBar` is a filled 50/50 bar directly under the title, inside a screen that is
already a tab in a bottom tab bar. Visually it reads as a segmented button, but functionally it
switches between two substantially different views (different data, different filters, different
result cards) — which is a tab.

The code comment says the thick bar was deliberate ("one screen with two lenses"). That intent is
right; the execution reads as a control, not a location.

**Fix:** Material secondary tabs — full-width, text labels, a 2–3dp accent indicator under the
active one, no fill. Distinct from every pill/segment elsewhere precisely *because* it's
navigation, not a setting.

### D3 · P0 — Swipe-to-demote has no undo

`onSwipeThrow` / `onSwipeBuy` call `demoteDisc(...)` immediately, and in Buy mode with the engine
on, `recordSwipeAway` also mutates learned preferences. The gesture is invisible until performed,
irreversible per-item, and one of its side effects silently teaches the recommender.

Android's convention for swipe actions is a Snackbar with **UNDO** (~5s). A bulk "Reset order"
elsewhere is not a substitute: undo has to be adjacent in time and scope to the action.

**Fix:** on swipe, show a Snackbar "Moved to bottom · UNDO"; UNDO reverses both the demotion and
the learning write. Bonus: it makes the gesture discoverable the first time it happens by accident.

### D4 · P1 — Buy-mode filters contradict the Bag screen's own pattern

Buy mode stacks, ungrouped, in the list header: category pill row, stability pill row, brand text
input, sort pill row (Best fit / Brand). Four control groups, one visual style, no labels.

The Bag screen already solved this exact problem: a collapsible `Filters & sort` panel with
`STABILITY` / `TYPE` / `SORT` group labels and a count badge on the collapsed toggle.

**Fix:** reuse it. Same component, same labels, same badge. Two screens doing the same job should
not teach two interfaces.

### D5 · P2 — `brandInput` needs the same clear affordance as Bag's search (see B5).

### D6 — What's working (keep)

The gap banner ("Your bag has no overstable fairway driver for max distance") is the single best
piece of copy in the app — it states a *finding*, not a feature. The `great/good/marginal` band
labels being computed from the untouched score while the learning penalty only affects ordering is
a genuinely subtle, correct design decision; don't let a refactor collapse the two.

---

## E. Score (`score.tsx`)

Structurally the strongest screen in the app. Findings are narrower.

### E1 · P0 — Custom header vs. the system Back button

`ActiveView` and `SummaryView` render their own header (`‹ Rounds` / title / `Finish`) while
remaining inside the Score tab — they're modes of one screen, not router destinations. That means
the hardware/gesture Back button probably does *not* map to `‹ Rounds`; it will exit the app or
switch tabs mid-round.

This is the classic iOS-pattern-on-Android bug, and mid-round is the worst possible place for it.

**Fix:** `BackHandler.addEventListener('hardwareBackPress', …)` while `mode !== 'list'`, returning
to the rounds list and returning `true`. **Verify on a device** — this one cannot be settled from
the source alone.

### E2 · P1 — `Finish` is a text link that ends a round

`Finish` sits top-right at the same visual weight as `‹ Rounds`, and in the code path I read there
is no confirmation before `onFinish`. Finishing a partially-scored round is a state change the user
can't obviously reverse from the same screen.

**Fix:** confirm when the round is incomplete ("3 holes unscored — finish anyway?"). When it *is*
complete, the existing bottom `Finish round` gradient button is the better primary — consider
dropping the header link at that point rather than offering two.

### E3 · P1 — Hole navigation is O(n) taps

`‹ ›` only: hole 17 of 18 is sixteen taps from hole 1 if you need to check an earlier score.

**Fix:** a horizontally scrollable hole strip (1…18 chips, current one filled, scored ones with a
dot). Costs ~40dp, and turns the scorecard into something you can review, not just advance
through. This also fills the dead space you get with 2 players.

### E4 · P2 — Running standings only exist on the Summary screen

During play, each player card shows their own total, but there's no leaderboard until the round is
finished — which is the moment it stops mattering. `standings(round)` is already computed in
`ActiveView` (`board`). Render a compact standings strip under the player cards.

### E5 · P2 — First-tap semantics on an unscored hole

Both `−` and `+` commit *par* on the first tap of an unscored hole (deliberate, per the code
comment: the ghost number is the starting point). It is defensible and it is also the kind of
thing that reads as a bug in the field the first time someone taps `+` expecting par+1. Worth
watching in real use; not worth changing on theory alone.

### E6 · P2 — `Σ` as the totals column header

Replace with `Tot` (see A3).

### E7 — What's working (keep)

Tap-the-number-to-open-exact-score-chips is excellent — one tap for a 6 instead of three `+`
presses — and the chip range (`1..par+4`, floored at 6, capped at 12) is a well-reasoned bound.
Only flaw: nothing signals the number is tappable. A faint underline or a tiny chevron under the
digit is enough.

---

## F. Settings (`settings.tsx`)

### F1 · P1 — This is a preference list styled as nine content cards

Nine+ elevated cards, each with an ALL-CAPS 10–11px label, a hint paragraph, and controls. Android
settings convention (Material / androidx `Preference`) is a flat grouped list: 14sp sentence-case
section headers in the accent color, one-line item titles, at most two lines of secondary text, and
anything longer behind a dialog.

The cards make every section look equally important — Default Throw View gets the same visual
weight as Backup & Restore.

**Fix:** flatten to grouped rows with headers and dividers (you already have `divider`,
`row`, `rowText`, `rowValue`, `rowChevron` — the vocabulary exists). Reserve card treatment for the
one or two sections that are genuinely actions, not preferences.

### F2 · P1 — The catalog picker is a single-choice setting rendered as three action rows

Built-in / Try Discs / Custom are mutually exclusive, and the current state is communicated by a
`✓ Active` string in the value slot while the other rows say `Switch` / `Download` / `Import` —
text that reads as a button but isn't (the whole row is the target).

**Fix:** a radio list. Selected source gets the radio; the *secondary* action (download,
re-import, check for updates) becomes an explicit trailing button or a sub-row. This is the
highest-value change on this screen: it turns "three things I can tap" into "one setting with three
values".

### F3 · P2 — State-echo lines duplicate the switch

Under Field View and Reference Images, a line restates the switch: "Off — Field view draws only the
discs in today's bag." The switch already says off; the sentence should carry only what the switch
can't (*consequence*, not *state*). Keep one constant explanation.

### F4 · P1 — Backup & Restore explainer

Two paragraphs plus a `noteBox` before the buttons. Collapse behind "Learn more".
*(Specified in the earlier handoff.)*

### F5 · P1 — Destructive action buried mid-list

`Delete all discs` sits inside the DATA card between Export and the catalog section, in
`colors.danger` (correct color) but not isolated. Convention is to place destructive actions last
on the screen, visually separated, never adjacent to routine rows a user taps often.

### F6 · P2 — Uppercase micro-labels

`sectionLabel` at 10–11px with `letterSpacing: 1` is below the readable floor and fights A4
(font scaling). Material section headers: 14sp, medium, sentence case, accent color.

---

## G. Priority order

If you only do six things, do these:

1. **A2** — touch targets to 44–48dp (invisible in mockups, felt immediately in the hand).
2. **E1** — hardware Back handling in the active scorecard (verify on device first).
3. **D3** — Snackbar UNDO for swipe-to-demote.
4. **A1 + A3** — one segmented control, one filter pill, one drawn icon set (kills the emoji, the
   glyph arrows and the three tint alphas in one pass).
5. **F2** — catalog picker becomes a radio list.
6. **B1** — Bag actions to primary + overflow.

Then: A4 (font scaling test at 200%), A5 (score-tier second channel), C2 (slider labeling),
D2/D4 (Suggest tabs + filter reuse), E3 (hole strip), F1 (settings as a preference list).

## H. Needs a device, not a code read

- E1 — what the Back button actually does mid-round.
- C5(b) — whether a cancelled slider gesture can leave `scrollEnabled` false.
- A4 — layout at 200% font scale, on all five tabs.
- A2 — whether the reorder arrows are hittable with a thumb, outdoors, in gloves.
- D3 — how often swipe-to-demote fires accidentally during a scroll.

## I. What not to change

The per-card flight-arc thumbnails, the gap banner copy, the quick-pick score chips, the three
distinct empty states, the "no network by default" posture surfaced honestly in Settings, and the
stability badge system (letter + color + consistent hue across every screen). These are the parts
of this app that most apps in this category don't have.

# Disc Tracker — design handoff

Everything from the design pass on the Android app: a full UI convention audit, four
implementation-ready changes, and three explored directions for the Disc Suggest scenario picker.

Nothing here changes the app's visual identity. Every color, radius, weight and component pattern
was read out of `app/src/theme.ts`, `static/style.css` and `app/src/components/*`. No new
dependencies, no new native modules — the F-Droid dependency set is unchanged.

---

## About the design files

The HTML files in `designs/` are **design references** — prototypes showing intended layout and
look. They are not production code to copy. Recreate them in the existing Expo / React Native
codebase using its established patterns: `StyleSheet.create`, `colors` from `src/theme.ts`,
`GradientButton`, `react-native-svg` for icons, screens under `app/app/(tabs)/`.

Do not add a CSS framework, a component library, or `expo-linear-gradient`.

**Fidelity: high.** Values in this document are exact and traceable to the codebase. Where a value
isn't listed, keep what the screen does today.

## How to read this package

| File | What it is |
|---|---|
| `README.md` | This file — the implementation spec. Start here. |
| `UX_AUDIT.md` | 30-finding convention audit across all five tabs, severity-ranked. The "why" behind everything below, plus findings not yet designed. |
| `designs/Before After.html` | Bag / Score / Settings — current vs. proposed, side by side. |
| `designs/Disc Suggest Options.html` | Scenario picker — today plus three directions (1a / 1b / 1c). **Needs a decision.** |
| `designs/Disc Tracker Refined.html` | First pass: four screens with the icon and hierarchy fixes applied. |
| `designs/android-frame.jsx`, `designs/support.js` | Scaffolding the HTML needs to render. Not part of the implementation. |

Open any `designs/*.html` in a browser.

---

# Part 1 — Ready to implement

Four changes, each independently revertable. Commit boundaries suggested at the end.

## 1.1 Bag — action hierarchy and overflow

**File:** `app/app/(tabs)/index.tsx` (the `actionsRow` block, ~lines 609–645)

**Today:** up to seven buttons wrap across two rows above the list — Add disc, Import, Export,
Share, My library (n), Clear bag, Field view — all `ghostBtn` except the gradient primary. Every
action reads equally urgent, and `Clear bag` is styled identically to `Export` despite being
destructive.

**Change:**

- **Primary, always visible:** `+ Add disc` — existing `GradientButton`, full width,
  `borderRadius: 10`, `paddingVertical: 12`, label 15/`'700'`/`#fff`.
- **Inline toggle:** `Field view` moves next to the `Filters & sort` row — it's a view mode, not an
  action. Outlined, `borderColor: colors.border`, `borderRadius: 8`, with the existing 24px
  target-circle icon at `colors.muted`.
- **Overflow (⋮):** Import CSV · Export CSV · Share bag report · My library (n) · divider ·
  **Clear today's bag** in `colors.danger` (#f87171), last and separated.
  Icon button top-right of the header, 44×44, `borderRadius: 22`,
  `backgroundColor: 'rgba(145,94,255,0.12)'`.

`Clear bag` keeps its existing confirmation `Alert` (index.tsx:451).

Reference: `designs/Before After.html`, row 1.

## 1.2 Flight Shaper — hand selector as one segmented row

**File:** `app/app/(tabs)/flight-shaper.tsx` (~line 214, the `ARC_VIEWS.map(...)` block)

**Today:** four boxed buttons in a 2×2 grid, ~120dp above the arc.

**Change:** one segmented control, four equal segments:

- Container: `flexDirection: 'row'`, `backgroundColor: colors.card`, `borderWidth: 1`,
  `borderColor: colors.border`, `borderRadius: 999`, `padding: 3`, `minHeight: 44`
- Segment: `flex: 1`, `paddingVertical: 6`, `borderRadius: 999`, centered, 12/`'600'`/`colors.muted`
- Selected: `backgroundColor: 'rgba(145,94,255,0.16)'`, `color: colors.accent`, `fontWeight: '700'`

Frees ~70dp for the arc. Use the same control in `settings.tsx` (~line 430, DEFAULT THROW VIEW).

## 1.3 Disc Suggest — vector scenario icons

**Files:** `app/src/utils/scenarios.ts` (`icon: string`, lines 23–140),
`app/src/components/ScenarioGrid.tsx`

**Today:** full-color emoji (`🚀 🌬 💨 ✋ 🪓`) mixed with monochrome glyphs (`➡ ↙ ↗ ⊙ ↪ ⟳ 〰`).
OEM font stacks render these inconsistently and TalkBack reads them literally.

**Change:** `icon: ScenarioIconName`, drawn with `react-native-svg` in the exact style of
`app/src/components/TabBarIcon.tsx`:

- `viewBox="0 0 24 24"`, `fill="none"`, `strokeWidth` 1.8–2, `strokeLinecap="round"`
- Stroke `colors.accent`; the three wind scenarios (Into Headwind, Tailwind, Crosswind) use
  `colors.sim` (#38bdf8) so conditions read as a family
- Badge unchanged, per `ScenarioGrid.tsx:60–71`: 44×44, `borderRadius: 22`,
  `backgroundColor: 'rgba(145,94,255,0.12)'`, `borderWidth: 1`,
  `borderColor: 'rgba(145,94,255,0.22)'`; active `0.28` fill with `colors.accent` border

All twelve glyphs are drawn at final size in `designs/Disc Suggest Options.html` (option 1a and 1b).

## 1.4 Settings — collapse the Backup & Restore explainer

**File:** `app/app/(tabs)/settings.tsx` (BACKUP & RESTORE card, ~lines 480–520)

**Today:** two paragraphs plus a `noteBox` before the buttons, pushing the actual Backup / Restore
actions below the fold.

**Change:** keep one visible line — *"One file: every disc, your settings, and all scorecards."* —
followed by a `Learn more` disclosure (12/`'600'`/`colors.accent` with a chevron that rotates when
open) that expands the existing copy **verbatim**. Nothing is deleted. Buttons move above the fold.
`LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut)` on toggle; no new dependency.

Worth applying to the REFERENCE IMAGES explainer too.

---

# Part 2 — Designed, needs your decision

## 2.1 Score — hole navigation and live standings

**File:** `app/app/(tabs)/score.tsx`, `ActiveView`

Two changes shown together in `designs/Before After.html`, row 2:

- **Hole strip** replacing `‹ ›`-only navigation: a horizontally scrollable row of hole chips,
  34×34, `borderRadius: 8`. Current hole filled `rgba(145,94,255,0.22)` with an accent border;
  scored holes tinted by tier (`colors.st` under par, `colors.muted` par, `colors.danger` over);
  unscored are outline-only. Any hole becomes one tap instead of up to seventeen, and the strip
  doubles as a scored/unscored map.
- **Standings strip** under the player cards, using the `standings(round)` value `ActiveView`
  already computes: rank · name · total (vs par). Fills the space a 2-player round leaves empty and
  puts the leaderboard where it matters — during the round, not after it.

Also add a 2px underline under the tappable stroke number so the quick-pick chip row is
discoverable.

## 2.2 Settings — preference list instead of nine cards

**File:** `app/app/(tabs)/settings.tsx`

Shown in `designs/Before After.html`, row 3. Flatten the card stack into grouped rows: 14sp
sentence-case section headers in `colors.accent`, one-line item titles, secondary text capped at two
lines. You already have `divider` / `row` / `rowText` / `rowValue` / `rowChevron`.

**The important part — the catalog picker becomes a radio group.** Built-in / Try Discs / Custom are
mutually exclusive, so render them as a single-choice list (20px radio, 2px `colors.accent` border,
10px filled dot when selected) with `Download` / `Import` as explicit trailing secondary buttons.
Today the state is a `✓ Active` string while other rows say `Switch` / `Download` — text that reads
as a button but isn't.

## 2.3 Disc Suggest scenario picker — three directions

`designs/Disc Suggest Options.html`. Pick one before implementing 1.3, since 1b and 1c change the
markup the icons live in.

| Option | What it is | Cost |
|---|---|---|
| **1a** | Same 2-up card grid, vector icons, one-line descriptions, Throw/Buy as real tabs with an indicator | Smallest change; still a scroll, a tap, then another scroll |
| **1b** | Full-width rows grouped Distance / Shape & control / Conditions / Overhead & specialty, each row able to carry a live "6 fit" count | Loses the card look; needs the grouping added to `scenarios.ts` |
| **1c** | Scenario becomes a pinned chip strip; the screen opens on results (last scenario restored) | Twelve scenarios live behind a horizontal scroll; first run needs a default |

**Recommendation: 1b for the picker, plus 1c's restore-last-scenario behavior** — the groups teach
the stability model, full-width rows are easier to hit, and the screen still lands on an answer
instead of a menu.

---

# Part 3 — From the audit, not yet designed

Highest value first. Full detail in `UX_AUDIT.md`.

1. **Touch targets (P0)** — seven controls measure 22–33dp against Android's 48dp minimum
   (`arcViewPill`, `pill`, `ghostBtn`, `reorderBtn`, `selBarBtn`, chevron rows). Keep every visual
   size; add `hitSlop` or `minHeight: 44`. Invisible in a screenshot, immediate in the hand.
2. **Hardware Back mid-round (P0)** — Score's `ActiveView` renders a custom `‹ Rounds` header while
   staying inside the tab, so the system Back button probably doesn't map to it. Needs
   `BackHandler` while `mode !== 'list'`. **Verify on a device.**
3. **Swipe-to-demote has no undo (P0)** — `demoteDisc` writes immediately and, with the engine on,
   `recordSwipeAway` also mutates learned preferences. Add a Snackbar with UNDO that reverses both.
4. **One control vocabulary (P1)** — five treatments and three tint alphas (0.12 / 0.16 / 0.28) for
   "pick one of N". Two components (`SegmentedControl`, `FilterPill`) and two tokens
   (`accentTint` 0.16, `accentTintStrong` 0.28).
5. **Glyphs as icons (P1)** — `▾ ▴ ▸ › ‹ ✕ ⤒ ↑ ↓ ✓ Σ` throughout. Extend `TabBarIcon.tsx` into a
   small `Icon` component. Same root cause as the scenario emoji.
6. **Font scaling (P0)** — fixed sizes with 10–12px chrome labels; test at 200% and set
   `maxFontSizeMultiplier` (~1.4) on dense labels only.
7. **Score tier color is the only signal (P0)** — add a shape or weight channel for red-green
   deficiency.
8. **Buy-mode filters (P1)** — reuse the Bag screen's collapsible `Filters & sort` panel with group
   labels and a count badge instead of four ungrouped pill rows.

---

## Design tokens (already in `app/src/theme.ts` — add nothing new)

```
bg        #0b0e1a     card      #141829     cardHover #1a1f36
border    #252b45     text      #e8eaf2     muted     #8b91ad
accent    #915EFF     os        #915EFF     st        #4ade80
us        #fbbf24     danger    #f87171     sim       #38bdf8
gradient  #A574FF → #7C48F0   (gradients.accent, 135°)
tints     rgba(145,94,255, 0.12 badge · 0.15 in-bag pill · 0.16 segment · 0.28 filter pill)
```

Radii: `12` cards · `10` primary buttons and mode bar · `8` secondary buttons, inputs, arc thumbs,
hole chips · `999` pills and badges.

Type (system stack): 26/`'800'` screen title · 18/`'700'` disc mold · 15/`'700'` primary button and
mode tab · 14/`'600'` stat value · 13 body and section hint · 12 meta · 11 badge · 10/14 card
description. Stability badges keep the outlined treatment from `static/style.css` — 1px border at
40% alpha over an 8% tint of the same hue.

## Assets

None new. Every icon is drawn inline with `react-native-svg`, already a dependency.

## Suggested commits

`bag: tier actions into primary + overflow` · `flight-shaper: segmented hand selector` ·
`suggest: vector scenario icons` · `settings: collapse backup explainer` ·
`score: hole strip + live standings` · `settings: catalog as radio group` ·
`a11y: touch targets to 48dp`

Verify on real hardware before merge, per the project's existing release discipline.
